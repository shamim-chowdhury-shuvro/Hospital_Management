<?php

require_once "../db.php";


/*
|--------------------------------------------------------------------------
| Get Bills
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $db,
    "SELECT
        b.billid,
        b.patientid,
        b.amount,
        b.paymentstatus,
        b.billdate,
        p.patientname,
        p.patienttype

     FROM bill b

     LEFT JOIN patient p
        ON b.patientid = p.patientid

     ORDER BY b.billid DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<title>
Billing Management - Hospital Management System
</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

<style>

.page-header
{
    margin-bottom:30px;
}

.billing-card
{
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 5px 25px rgba(0,0,0,.07);
}

.table thead th
{
    white-space:nowrap;
}

.amount
{
    font-weight:700;
}

.empty-state
{
    padding:50px 20px;
    text-align:center;
    color:#64748b;
}

</style>

</head>

<body>


<div class="container-fluid mt-4 mb-5">


<!-- HEADER -->

<div class="page-header d-flex justify-content-between align-items-center">


<div>

<h2 class="fw-bold mb-1">
Billing Management
</h2>

<p class="text-muted mb-0">
View and manage patient bills
</p>

</div>


<div>

<a
href="add.php"
class="btn btn-primary">

+ Add Bill

</a>


<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>


</div>


<!-- BILL TABLE -->

<div class="billing-card">


<div class="table-responsive">


<table class="table table-hover align-middle">


<thead class="table-primary">


<tr>

<th>
Bill ID
</th>

<th>
Patient
</th>

<th>
Patient Type
</th>

<th>
Amount
</th>

<th>
Payment Status
</th>

<th>
Bill Date
</th>

<th>
Action
</th>

</tr>


</thead>


<tbody>


<?php

if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_assoc($result))
{

?>


<tr>


<!-- BILL ID -->

<td>

<span class="fw-semibold">

<?php

echo $row['billid'];

?>

</span>

</td>


<!-- PATIENT -->

<td>

<strong>

<?php

echo htmlspecialchars(
    $row['patientname']
    ?? 'Unknown Patient'
);

?>

</strong>

</td>


<!-- PATIENT TYPE -->

<td>

<?php

if(
    isset($row['patienttype'])
    &&
    $row['patienttype'] == "Indoor"
)
{

?>

<span class="badge bg-primary">

Indoor

</span>

<?php

}
else
{

?>

<span class="badge bg-info text-dark">

Outdoor

</span>

<?php

}

?>

</td>


<!-- AMOUNT -->

<td>

<span class="amount">

৳

<?php

echo number_format(
    (float)$row['amount'],
    2
);

?>

</span>

</td>


<!-- PAYMENT STATUS -->

<td>


<?php

if($row['paymentstatus'] == "Paid")
{

?>

<span class="badge bg-success">

Paid

</span>

<?php

}
elseif($row['paymentstatus'] == "Partial")
{

?>

<span class="badge bg-warning text-dark">

Partial

</span>

<?php

}
elseif($row['paymentstatus'] == "Unpaid")
{

?>

<span class="badge bg-danger">

Unpaid

</span>

<?php

}
else
{

?>

<span class="badge bg-secondary">

<?php

echo htmlspecialchars(
    $row['paymentstatus']
);

?>

</span>

<?php

}

?>


</td>


<!-- BILL DATE -->

<td>

<?php

echo htmlspecialchars(
    $row['billdate']
);

?>

</td>


<!-- ACTION -->

<td>

<a
href="update.php?id=<?php echo $row['billid']; ?>"
class="btn btn-sm btn-warning mb-1">

Edit

</a>


<a
href="delete.php?id=<?php echo $row['billid']; ?>"
class="btn btn-sm btn-outline-danger mb-1"

onclick="return confirm('Are you sure you want to delete this bill?');">

Delete

</a>

</td>


</tr>


<?php

}

}
else
{

?>


<tr>

<td
colspan="7">

<div class="empty-state">

<h5 class="fw-bold">
No Bills Found
</h5>

<p class="mb-3">
There are currently no billing records.
</p>

<a
href="add.php"
class="btn btn-primary">

Create First Bill

</a>

</div>

</td>

</tr>


<?php

}

?>


</tbody>


</table>


</div>


</div>


</div>


</body>

</html>