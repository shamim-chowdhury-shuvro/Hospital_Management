<?php

require_once "../db.php";

$error = "";

if(!isset($_GET['id']) || empty($_GET['id']))
{
    header("Location:view.php");
    exit();
}

$id = $_GET['id'];


/*
|--------------------------------------------------------------------------
| Get Existing Bill
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $db,
    "SELECT *
     FROM bill
     WHERE billid='$id'"
);

if(mysqli_num_rows($result) == 0)
{
    header("Location:view.php");
    exit();
}

$row = mysqli_fetch_assoc($result);


/*
|--------------------------------------------------------------------------
| Get Patients
|--------------------------------------------------------------------------
*/

$patients = mysqli_query(
    $db,
    "SELECT patientid, patientname, patienttype
     FROM patient
     ORDER BY patientname"
);


/*
|--------------------------------------------------------------------------
| Update Bill
|--------------------------------------------------------------------------
*/

if(isset($_POST['update']))
{
    $patientid = $_POST['patientid'];
    $amount = $_POST['amount'];
    $paymentstatus = $_POST['paymentstatus'];
    $billdate = $_POST['billdate'];


    /*
     * Validate amount
     */

    if($amount < 0)
    {
        $error = "Amount cannot be negative.";
    }
    else
    {

        $update = mysqli_query(
            $db,
            "UPDATE bill

             SET
                patientid='$patientid',
                amount='$amount',
                paymentstatus='$paymentstatus',
                billdate='$billdate'

             WHERE billid='$id'"
        );


        if($update)
        {
            header("Location:view.php");
            exit();
        }
        else
        {
            $error = mysqli_error($db);
        }
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>
Update Bill - Hospital Management System
</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

<style>

.bill-card
{
    max-width:800px;
    margin:auto;
    background:white;
    border-radius:20px;
    padding:35px;
    box-shadow:0 5px 25px rgba(0,0,0,.08);
}

</style>

</head>

<body>


<div class="container mt-5 mb-5">


<div class="bill-card">


<!-- HEADER -->

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold mb-1">
Update Bill
</h2>

<p class="text-muted mb-0">
Edit patient billing information
</p>

</div>


<a
href="view.php"
class="btn btn-outline-secondary">

Back

</a>

</div>


<?php

if($error != "")
{

?>

<div class="alert alert-danger">

<?php

echo htmlspecialchars($error);

?>

</div>

<?php

}

?>


<form method="POST">


<!-- PATIENT -->

<div class="mb-4">

<label class="form-label fw-semibold">

Patient

</label>

<select
name="patientid"
class="form-select"
required>

<?php

while($p = mysqli_fetch_assoc($patients))
{

?>

<option
value="<?php echo $p['patientid']; ?>"

<?php

if($p['patientid'] == $row['patientid'])
{
    echo "selected";
}

?>

>

<?php

echo htmlspecialchars(
    $p['patientname']
);

?>

&nbsp; — &nbsp;

<?php

echo htmlspecialchars(
    $p['patienttype']
);

?>

</option>

<?php

}

?>

</select>

</div>


<!-- AMOUNT -->

<div class="mb-4">

<label class="form-label fw-semibold">

Bill Amount

</label>

<div class="input-group">

<span class="input-group-text">
৳
</span>

<input
type="number"
name="amount"
class="form-control"
step="0.01"
min="0"
value="<?php echo htmlspecialchars($row['amount']); ?>"
required>

</div>

</div>


<!-- PAYMENT STATUS -->

<div class="mb-4">

<label class="form-label fw-semibold">

Payment Status

</label>

<select
name="paymentstatus"
class="form-select"
required>

<option
value="Paid"

<?php

if($row['paymentstatus'] == "Paid")
{
    echo "selected";
}

?>

>

Paid

</option>


<option
value="Unpaid"

<?php

if($row['paymentstatus'] == "Unpaid")
{
    echo "selected";
}

?>

>

Unpaid

</option>


<option
value="Partial"

<?php

if($row['paymentstatus'] == "Partial")
{
    echo "selected";
}

?>

>

Partial

</option>

</select>

</div>


<!-- BILL DATE -->

<div class="mb-4">

<label class="form-label fw-semibold">

Bill Date

</label>

<input
type="date"
name="billdate"
class="form-control"
value="<?php echo htmlspecialchars($row['billdate']); ?>"
required>

</div>


<!-- INFORMATION -->

<div class="alert alert-info">

You can update the patient, bill amount,
payment status and bill date.

</div>


<!-- BUTTONS -->

<div class="mt-4">

<button
type="submit"
name="update"
class="btn btn-primary px-4">

Update Bill

</button>


<a
href="view.php"
class="btn btn-outline-secondary ms-2">

Cancel

</a>


<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>


</form>


</div>

</div>


</body>

</html>