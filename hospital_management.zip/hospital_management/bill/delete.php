<?php

require_once "../db.php";


/*
|--------------------------------------------------------------------------
| Check Bill ID
|--------------------------------------------------------------------------
*/

if(!isset($_GET['id']) || empty($_GET['id']))
{
    header("Location:view.php");
    exit();
}


$id = $_GET['id'];


/*
|--------------------------------------------------------------------------
| Check Bill Exists
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $db,
    "SELECT billid
     FROM bill
     WHERE billid='$id'"
);


if(mysqli_num_rows($result) == 0)
{
    header("Location:view.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| Delete Bill
|--------------------------------------------------------------------------
*/

$delete = mysqli_query(
    $db,
    "DELETE FROM bill
     WHERE billid='$id'"
);


if($delete)
{
    header("Location:view.php");
    exit();
}
else
{
    echo "Error deleting bill: "
         . mysqli_error($db);
}

?>