<?php

require_once "../db.php";

$id = $_GET['id'];

mysqli_query(
$db,
"DELETE FROM prescription
WHERE prescriptionid='$id'"
);

header("Location:view.php");
exit();

?>