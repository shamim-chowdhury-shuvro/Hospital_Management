<?php

require_once "../db.php";

$id = $_GET['id'];

$result = mysqli_query(
$db,
"SELECT *
FROM prescription
WHERE prescriptionid='$id'"
);

$row = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $diagnosis = $_POST['diagnosis'];
    $prescriptiondate = $_POST['prescriptiondate'];

    mysqli_query(
    $db,
    "UPDATE prescription
    SET
    diagnosis='$diagnosis',
    prescriptiondate='$prescriptiondate'
    WHERE prescriptionid='$id'"
    );

    header("Location:view.php");
    exit();
}

?>

<form method="POST">

Diagnosis:

<textarea name="diagnosis">

<?php echo $row['diagnosis']; ?>

</textarea>

<br><br>

Date:

<input
type="date"
name="prescriptiondate"
value="<?php echo $row['prescriptiondate']; ?>">

<br><br>

<input
type="submit"
name="update"
value="Update">

</form>

<br><br>

<a href="../dashboard.php">
Back To Dashboard
</a>