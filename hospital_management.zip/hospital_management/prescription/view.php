<?php

require_once "../db.php";


$result = mysqli_query(
    $db,
    "SELECT *
     FROM prescription
     ORDER BY prescriptionid DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<title>
Prescription Management
</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<style>

body
{
    background:#f4f7fb;
}

.page-card
{
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 5px 25px rgba(0,0,0,.07);
}

.page-header
{
    margin-bottom:25px;
}

</style>

</head>

<body>


<div class="container-fluid mt-4 mb-5">


<!-- HEADER -->

<div class="page-header d-flex justify-content-between align-items-center">

<div>

<h2 class="fw-bold mb-1">

Prescription Management

</h2>

<p class="text-muted mb-0">

View and manage patient prescriptions

</p>

</div>


<div>

<a
href="add.php"
class="btn btn-primary">

+ Add Prescription

</a>


<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>

</div>


<!-- TABLE -->

<div class="page-card">

<div class="table-responsive">


<table class="table table-hover align-middle">


<thead class="table-primary">

<tr>

<th>
Prescription ID
</th>

<th>
Appointment ID
</th>

<th>
Diagnosis
</th>

<th>
Prescription Date
</th>

<th>
Action
</th>

</tr>

</thead>


<tbody>


<?php

if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_assoc($result))
{

?>


<tr>


<td>

<strong>

<?php

echo $row['prescriptionid'];

?>

</strong>

</td>


<td>

<?php

echo $row['appointmentid'];

?>

</td>


<td>

<?php

echo htmlspecialchars(
    $row['diagnosis']
);

?>

</td>


<td>

<?php

echo $row['prescriptiondate'];

?>

</td>


<td>


<a
href="update.php?id=<?php echo $row['prescriptionid']; ?>"
class="btn btn-sm btn-warning">

Edit

</a>


<a
href="delete.php?id=<?php echo $row['prescriptionid']; ?>"
class="btn btn-sm btn-danger"

onclick="return confirm('Are you sure you want to delete this prescription?');">

Delete

</a>


<a
href="../prescription_management/add.php?id=<?php echo $row['prescriptionid']; ?>"
class="btn btn-sm btn-success">

Add Medicine

</a>


<a
href="../prescription_management/view.php?id=<?php echo $row['prescriptionid']; ?>"
class="btn btn-sm btn-info text-white">

View Medicines

</a>


</td>


</tr>


<?php

}

}
else
{

?>


<tr>

<td
colspan="5"
class="text-center py-5">

<h5 class="fw-bold">

No Prescription Found

</h5>

<p class="text-muted">

No prescription has been added yet.

</p>


<a
href="add.php"
class="btn btn-primary">

Add Prescription

</a>

</td>

</tr>


<?php

}

?>


</tbody>


</table>


</div>

</div>


</div>


</body>

</html>