<?php

require_once "../db.php";

$appointments = mysqli_query(
$db,
"SELECT appointmentid
FROM appointment"
);

if(isset($_POST['submit']))
{
    $appointmentid = $_POST['appointmentid'];
    $diagnosis = $_POST['diagnosis'];
    $prescriptiondate = $_POST['prescriptiondate'];

    mysqli_query(
    $db,
    "INSERT INTO prescription
    (
        appointmentid,
        diagnosis,
        prescriptiondate
    )
    VALUES
    (
        '$appointmentid',
        '$diagnosis',
        '$prescriptiondate'
    )"
    );

    header("Location:view.php");
    exit();
}

?>

<h2>Add Prescription</h2>

<form method="POST">

Appointment:

<select name="appointmentid">

<?php

while($a=mysqli_fetch_assoc($appointments))
{

?>

<option value="<?php echo $a['appointmentid']; ?>">

<?php echo $a['appointmentid']; ?>

</option>

<?php

}

?>

</select>

<br><br>

Diagnosis:

<textarea
name="diagnosis"
required>
</textarea>

<br><br>

Prescription Date:

<input
type="date"
name="prescriptiondate"
required>

<br><br>

<input
type="submit"
name="submit"
value="Create Prescription">

</form>

<br><br>

<a href="../dashboard.php">
Back To Dashboard
</a>