<?php

require_once "../db.php";

if(isset($_POST['submit']))
{
    $patientname = $_POST['patientname'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $bloodgroup = $_POST['bloodgroup'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $emergencycontact = $_POST['emergencycontact'];
    $patienttype = $_POST['patienttype'];

    $sql = "INSERT INTO patient
    (
        patientname,
        gender,
        age,
        bloodgroup,
        phone,
        address,
        emergencycontact,
        patienttype
    )
    VALUES
    (
        '$patientname',
        '$gender',
        '$age',
        '$bloodgroup',
        '$phone',
        '$address',
        '$emergencycontact',
        '$patienttype'
    )";

    if(mysqli_query($db,$sql))
    {
        header("Location:view.php");
        exit();
    }
    else
    {
        $error = mysqli_error($db);
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Add Patient - Hospital Management System</title>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

</head>

<body>

<div class="container mt-4 mb-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Add Patient
</h2>

<p class="text-muted mb-0">
Register a new patient
</p>

</div>

<a
href="../dashboard.php"
class="btn btn-primary">

Dashboard

</a>

</div>

<div class="form-card">

<?php

if(isset($error))
{

?>

<div class="alert alert-danger">

<?php echo $error; ?>

</div>

<?php

}

?>

<form method="POST">

<div class="row">

<div class="col-md-6 mb-3">

<label class="form-label">
Patient Name
</label>

<input
type="text"
name="patientname"
class="form-control"
placeholder="Enter patient name"
required>

</div>

<div class="col-md-3 mb-3">

<label class="form-label">
Gender
</label>

<select
name="gender"
class="form-select"
required>

<option value="">
Select Gender
</option>

<option value="Male">
Male
</option>

<option value="Female">
Female
</option>

<option value="Other">
Other
</option>

</select>

</div>

<div class="col-md-3 mb-3">

<label class="form-label">
Age
</label>

<input
type="number"
name="age"
class="form-control"
placeholder="Age"
min="0"
required>

</div>

<div class="col-md-4 mb-3">

<label class="form-label">
Blood Group
</label>

<select
name="bloodgroup"
class="form-select">

<option value="">
Select Blood Group
</option>

<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>

</select>

</div>

<div class="col-md-4 mb-3">

<label class="form-label">
Phone
</label>

<input
type="text"
name="phone"
class="form-control"
placeholder="Enter phone number">

</div>

<div class="col-md-4 mb-3">

<label class="form-label">
Emergency Contact
</label>

<input
type="text"
name="emergencycontact"
class="form-control"
placeholder="Emergency contact">

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Patient Type
</label>

<select
name="patienttype"
class="form-select"
required>

<option value="Outdoor">
Outdoor
</option>

<option value="Indoor">
Indoor
</option>

</select>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Address
</label>

<input
type="text"
name="address"
class="form-control"
placeholder="Enter address">

</div>

</div>

<div class="mt-3">

<button
type="submit"
name="submit"
class="btn btn-primary px-4">

Save Patient

</button>

<a
href="view.php"
class="btn btn-outline-secondary ms-2">

View Patients

</a>

</div>

</form>

</div>

</div>

</body>

</html>