<?php

require_once "../db.php";

$id = $_GET['id'];

$sql = "SELECT * FROM patient
        WHERE patientid='$id'";

$result = mysqli_query($db,$sql);

$row = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $patientname = $_POST['patientname'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $bloodgroup = $_POST['bloodgroup'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $emergencycontact = $_POST['emergencycontact'];
    $patienttype = $_POST['patienttype'];

    $sql = "UPDATE patient
            SET
            patientname='$patientname',
            gender='$gender',
            age='$age',
            bloodgroup='$bloodgroup',
            phone='$phone',
            address='$address',
            emergencycontact='$emergencycontact',
            patienttype='$patienttype'
            WHERE patientid='$id'";

    if(mysqli_query($db,$sql))
    {
        header("Location: view.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Update Patient</title>
</head>
<body>

<h2>Update Patient</h2>

<form method="POST">

    Patient Name:
    <input type="text"
           name="patientname"
           value="<?php echo $row['patientname']; ?>">

    <br><br>

    Gender:
    <input type="text"
           name="gender"
           value="<?php echo $row['gender']; ?>">

    <br><br>

    Age:
    <input type="number"
           name="age"
           value="<?php echo $row['age']; ?>">

    <br><br>

    Blood Group:
    <input type="text"
           name="bloodgroup"
           value="<?php echo $row['bloodgroup']; ?>">

    <br><br>

    Phone:
    <input type="text"
           name="phone"
           value="<?php echo $row['phone']; ?>">

    <br><br>

    Address:
    <input type="text"
           name="address"
           value="<?php echo $row['address']; ?>">

    <br><br>

    Emergency Contact:
    <input type="text"
           name="emergencycontact"
           value="<?php echo $row['emergencycontact']; ?>">

    <br><br>

    Patient Type:

    <select name="patienttype">

        <option value="Outdoor"
        <?php
        if($row['patienttype']=="Outdoor")
        {
            echo "selected";
        }
        ?>>
        Outdoor
        </option>

        <option value="Indoor"
        <?php
        if($row['patienttype']=="Indoor")
        {
            echo "selected";
        }
        ?>>
        Indoor
        </option>

    </select>

    <br><br>

    <input type="submit"
           name="update"
           value="Update Patient">

</form>

<br><br>

<a href="../dashboard.php">
Back To Dashboard
</a>

</body>
</html>