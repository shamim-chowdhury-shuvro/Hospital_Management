<?php

require_once "../db.php";

$result = mysqli_query(
    $db,
    "SELECT * FROM patient ORDER BY patientid DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<title>Patient Management - Hospital Management System</title>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

</head>

<body>

<div class="container-fluid mt-4 mb-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Patient Management
</h2>

<p class="text-muted mb-0">
View and manage registered patients
</p>

</div>

<div>

<a
href="add.php"
class="btn btn-primary">

+ Add Patient

</a>

<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>

</div>

<div class="table-card">

<div class="table-responsive">

<table class="table table-hover table-bordered align-middle">

<thead class="table-primary">

<tr>

<th>ID</th>

<th>Patient Name</th>

<th>Gender</th>

<th>Age</th>

<th>Blood Group</th>

<th>Phone</th>

<th>Patient Type</th>

<th>Address</th>

<th>Emergency Contact</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php

if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_assoc($result))
{

?>

<tr>

<td>
<?php echo $row['patientid']; ?>
</td>

<td>

<strong>
<?php echo htmlspecialchars($row['patientname']); ?>
</strong>

</td>

<td>
<?php echo htmlspecialchars($row['gender']); ?>
</td>

<td>
<?php echo $row['age']; ?>
</td>

<td>

<span class="badge bg-danger">

<?php echo htmlspecialchars($row['bloodgroup']); ?>

</span>

</td>

<td>
<?php echo htmlspecialchars($row['phone']); ?>
</td>

<td>

<?php

if($row['patienttype'] == "Indoor")
{

?>

<span class="badge bg-success">
Indoor
</span>

<?php

}
else
{

?>

<span class="badge bg-info text-dark">
Outdoor
</span>

<?php

}

?>

</td>

<td>
<?php echo htmlspecialchars($row['address']); ?>
</td>

<td>
<?php echo htmlspecialchars($row['emergencycontact']); ?>
</td>

<td>

<a
href="update.php?id=<?php echo $row['patientid']; ?>"
class="btn btn-sm btn-warning">

Edit

</a>

<a
href="delete.php?id=<?php echo $row['patientid']; ?>"
class="btn btn-sm btn-danger"
onclick="return confirm('Are you sure you want to delete this patient?');">

Delete

</a>

</td>

</tr>

<?php

}

}
else
{

?>

<tr>

<td
colspan="10"
class="text-center text-muted py-4">

No patients found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

</body>

</html>