<?php

require_once "../db.php";

$id = $_GET['id'];

$sql = "DELETE FROM patient
        WHERE patientid='$id'";

mysqli_query($db,$sql);

header("Location:view.php");

?>