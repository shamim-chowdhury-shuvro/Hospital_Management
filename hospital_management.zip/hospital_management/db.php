<?php

$hostname = "localhost";
$username = "root";
$password = "";
$databasename = "hospital_management";

$db = new mysqli(
    $hostname,
    $username,
    $password,
    $databasename
);

if($db->connect_error)
{
    die("Connection Failed");
}

?>