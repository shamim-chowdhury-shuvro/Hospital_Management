<?php

session_start();

require_once "db.php";

if(!isset($_SESSION['username']))
{
    header("Location:login.php");
    exit();
}

$p = mysqli_fetch_assoc(
mysqli_query($db,"SELECT COUNT(*) AS total FROM patient")
);

$d = mysqli_fetch_assoc(
mysqli_query($db,"SELECT COUNT(*) AS total FROM doctor")
);

$a = mysqli_fetch_assoc(
mysqli_query($db,"SELECT COUNT(*) AS total FROM appointment")
);

$ad = mysqli_fetch_assoc(
mysqli_query($db,"SELECT COUNT(*) AS total FROM admission")
);

$m = mysqli_fetch_assoc(
mysqli_query($db,"SELECT COUNT(*) AS total FROM medicine")
);

$b = mysqli_fetch_assoc(
mysqli_query($db,"SELECT SUM(amount) AS total FROM bill")
);

$pr = mysqli_fetch_assoc(
mysqli_query(
$db,
"SELECT COUNT(*) AS total
FROM prescription"
)
);

$availableBeds = mysqli_fetch_assoc(
mysqli_query(
$db,
"SELECT COUNT(*) AS total
FROM bed
WHERE status='Available'"
)
);

$occupiedBeds = mysqli_fetch_assoc(
mysqli_query(
$db,
"SELECT COUNT(*) AS total
FROM bed
WHERE status='Occupied'"
)
);

?>

<!DOCTYPE html>

<html>

<head>

<title>Hospital Management System</title>

<meta charset="utf-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="style.css">

</head>

<body>

<div class="container-fluid">

<div class="row">

<!-- SIDEBAR START -->

<div class="col-md-2 sidebar">

<h3>
🏥 HMS
</h3>

<a href="dashboard.php">
📊 Dashboard
</a>

<hr class="text-white">

<a href="patient/add.php">
➕ Add Patient
</a>

<a href="patient/view.php">
👤 View Patient
</a>

<a href="doctor/add.php">
➕ Add Doctor
</a>

<a href="doctor/view.php">
👨‍⚕️ View Doctor
</a>

<a href="appointment/add.php">
➕ Add Appointment
</a>

<a href="appointment/view.php">
📅 View Appointment
</a>

<a href="admission/add.php">
➕ Add Admission
</a>

<a href="admission/view.php">
🛏 View Admission
</a>

<a href="bill/add.php">
➕ Add Bill
</a>

<a href="bill/view.php">
💵 View Bill
</a>

<a href="medicine/add.php">
➕ Add Medicine
</a>

<a href="medicine/view.php">
💊 View Medicine
</a>

<a href="prescription/add.php">
➕ Add Prescription
</a>

<a href="prescription/view.php">
📋 View Prescription
</a>

<hr class="text-white">

<a href="logout.php">
🚪 Logout
</a>

</div>

<!-- SIDEBAR END -->

<!-- MAIN CONTENT START -->

<div class="col-md-10 main-content">

<div class="topbar">

<h2>
🏥 Hospital Management System
</h2>

<p>

Welcome Back,

<b>

<?php
echo $_SESSION['username'];
?>

</b>

</p>

</div>

<!-- STATISTICS CARDS -->

<div class="row">

<div class="col-md-4 mb-4">

<div class="stat-card bg-patient">

<h5>Total Patients</h5>

<h1>

<?php
echo $p['total'];
?>

</h1>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="stat-card bg-doctor">

<h5>Total Doctors</h5>

<h1>

<?php
echo $d['total'];
?>

</h1>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="stat-card bg-appointment">

<h5>Total Appointments</h5>

<h1>

<?php
echo $a['total'];
?>

</h1>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="stat-card bg-admission">

<h5>Total Admissions</h5>

<h1>

<?php
echo $ad['total'];
?>

</h1>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="stat-card bg-medicine">

<h5>Total Medicines</h5>

<h1>

<?php
echo $m['total'];
?>

</h1>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="stat-card bg-revenue">

<h5>Total Revenue</h5>

<h1>

<?php

echo ($b['total']==NULL)
? 0
: $b['total'];

?>

</h1>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="stat-card bg-success">

<h5>Available Beds</h5>

<h1>

<?php echo $availableBeds['total']; ?>

</h1>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="stat-card bg-danger">

<h5>Occupied Beds</h5>

<h1>

<?php echo $occupiedBeds['total']; ?>

</h1>

</div>

</div>

<div class="col-md-4 mb-4">

<div class="stat-card bg-dark">

<h5>Total Prescriptions</h5>

<h1>

<?php echo $pr['total']; ?>

</h1>

</div>

</div>

</div>

<!-- MODULE SECTION -->

<div class="card info-card">

<div class="card-body">

<h3>
System Modules
</h3>

<hr>

<div class="row">

<div class="col-md-4">

<ul class="module-list">

<li>👤 Patient Management</li>
<li>👨‍⚕️ Doctor Management</li>
<li>📅 Appointment Management</li>

</ul>

</div>

<div class="col-md-4">

<ul class="module-list">

<li>🛏 Admission Management</li>
<li>💵 Billing Management</li>
<li>💊 Medicine Management</li>

</ul>

</div>

<div class="col-md-4">

<ul class="module-list">

<li>📋 Prescription Management</li>
<li>🔐 Login System</li>
<li>📊 Dashboard Reporting</li>

</ul>

</div>

</div>

</div>

</div>

<br>

<!-- QUICK ACCESS -->

<div class="card info-card">

<div class="card-body">

<h3>
Quick Access
</h3>

<hr>

<a
href="patient/add.php"
class="btn btn-primary m-1">
Add Patient
</a>

<a
href="doctor/add.php"
class="btn btn-success m-1">
Add Doctor
</a>

<a
href="appointment/add.php"
class="btn btn-warning m-1">
Add Appointment
</a>

<a
href="admission/add.php"
class="btn btn-secondary m-1">
Add Admission
</a>

<a
href="bill/add.php"
class="btn btn-danger m-1">
Add Bill
</a>

<a
href="medicine/add.php"
class="btn btn-info m-1">
Add Medicine
</a>

<a
href="prescription/add.php"
class="btn btn-dark m-1">
Add Prescription
</a>

</div>

</div>

</div>

<!-- MAIN CONTENT END -->

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>