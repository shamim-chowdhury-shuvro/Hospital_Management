<?php

require_once "../db.php";

$error = "";

if(isset($_POST['submit']))
{
    $medicinename = trim($_POST['medicinename']);
    $stock = (int)$_POST['stock'];
    $price = (float)$_POST['price'];
    $expirydate = $_POST['expirydate'];

    if($medicinename == "")
    {
        $error = "Medicine name is required.";
    }
    elseif($stock < 0)
    {
        $error = "Stock cannot be negative.";
    }
    elseif($price < 0)
    {
        $error = "Price cannot be negative.";
    }
    elseif($expirydate == "")
    {
        $error = "Expiry date is required.";
    }
    else
    {
        $medicinename = mysqli_real_escape_string(
            $db,
            $medicinename
        );

        $expirydate = mysqli_real_escape_string(
            $db,
            $expirydate
        );

        $insert = mysqli_query(
            $db,
            "INSERT INTO medicine
            (
                medicinename,
                stock,
                price,
                expirydate
            )
            VALUES
            (
                '$medicinename',
                '$stock',
                '$price',
                '$expirydate'
            )"
        );

        if($insert)
        {
            header("Location:view.php");
            exit();
        }
        else
        {
            $error = "Unable to add medicine: " . mysqli_error($db);
        }
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Add Medicine</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<style>

body
{
    background:#f4f7fb;
}

.form-card
{
    max-width:850px;
    margin:40px auto;
    background:white;
    padding:40px;
    border-radius:22px;
    box-shadow:0 8px 30px rgba(0,0,0,.08);
}

</style>

</head>

<body>

<div class="container">

<div class="form-card">

<h2 class="fw-bold mb-1">
Add Medicine
</h2>

<p class="text-muted mb-4">
Add a new medicine to the hospital inventory.
</p>


<?php

if($error != "")
{

?>

<div class="alert alert-danger">

<?php echo htmlspecialchars($error); ?>

</div>

<?php

}

?>


<form method="POST">


<div class="mb-3">

<label class="form-label fw-semibold">
Medicine Name
</label>

<input
type="text"
name="medicinename"
class="form-control"
placeholder="Enter medicine name"
required>

</div>


<div class="mb-3">

<label class="form-label fw-semibold">
Stock
</label>

<input
type="number"
name="stock"
class="form-control"
min="0"
placeholder="Enter available stock"
required>

</div>


<div class="mb-3">

<label class="form-label fw-semibold">
Price
</label>

<div class="input-group">

<span class="input-group-text">
৳
</span>

<input
type="number"
name="price"
class="form-control"
step="0.01"
min="0"
placeholder="Enter medicine price"
required>

</div>

</div>


<div class="mb-4">

<label class="form-label fw-semibold">
Expiry Date
</label>

<input
type="date"
name="expirydate"
class="form-control"
required>

</div>


<button
type="submit"
name="submit"
class="btn btn-primary px-4">

Add Medicine

</button>


<a
href="view.php"
class="btn btn-outline-secondary ms-2">

Cancel

</a>


<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>


</form>

</div>

</div>

</body>

</html>