<?php

require_once "../db.php";

$result = mysqli_query(
    $db,
    "SELECT *
     FROM medicine
     ORDER BY medicineid DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<title>Medicine Management</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<style>

body
{
    background:#f4f7fb;
}

.page-card
{
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 5px 25px rgba(0,0,0,.07);
}

.table th
{
    white-space:nowrap;
}

</style>

</head>

<body>


<div class="container-fluid mt-4 mb-5">


<!-- HEADER -->

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold mb-1">
Medicine Management
</h2>

<p class="text-muted mb-0">
View and manage hospital medicines.
</p>

</div>


<div>

<a
href="add.php"
class="btn btn-primary">

+ Add Medicine

</a>


<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>

</div>


<!-- TABLE -->

<div class="page-card">

<div class="table-responsive">


<table class="table table-hover align-middle">


<thead class="table-primary">

<tr>

<th>ID</th>

<th>Medicine Name</th>

<th>Stock</th>

<th>Price</th>

<th>Expiry Date</th>

<th>Status</th>

<th>Action</th>

</tr>

</thead>


<tbody>


<?php

if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_assoc($result))
{

$stock = (int)$row['stock'];

$expiry = $row['expirydate'];

$today = date('Y-m-d');


/*
|--------------------------------------------------------------------------
| Stock Status
|--------------------------------------------------------------------------
*/

if($stock == 0)
{
    $stockStatus = "Out of Stock";
    $stockClass = "bg-danger";
}
elseif($stock <= 10)
{
    $stockStatus = "Low Stock";
    $stockClass = "bg-warning text-dark";
}
else
{
    $stockStatus = "Available";
    $stockClass = "bg-success";
}


/*
|--------------------------------------------------------------------------
| Expiry Status
|--------------------------------------------------------------------------
*/

if($expiry < $today)
{
    $expiryStatus = "Expired";
    $expiryClass = "bg-danger";
}
elseif($expiry <= date('Y-m-d', strtotime('+30 days')))
{
    $expiryStatus = "Expiring Soon";
    $expiryClass = "bg-warning text-dark";
}
else
{
    $expiryStatus = "Valid";
    $expiryClass = "bg-success";
}

?>


<tr>


<td>

<?php

echo $row['medicineid'];

?>

</td>


<td>

<strong>

<?php

echo htmlspecialchars(
    $row['medicinename']
);

?>

</strong>

</td>


<td>

<?php

echo $stock;

?>

</td>


<td>

৳

<?php

echo number_format(
    (float)$row['price'],
    2
);

?>

</td>


<td>

<?php

echo $expiry;

?>

</td>


<td>

<span class="badge <?php echo $stockClass; ?>">

<?php

echo $stockStatus;

?>

</span>

<br>

<span class="badge <?php echo $expiryClass; ?> mt-1">

<?php

echo $expiryStatus;

?>

</span>

</td>


<td>

<a
href="update.php?id=<?php echo $row['medicineid']; ?>"
class="btn btn-sm btn-warning">

Edit

</a>


<a
href="delete.php?id=<?php echo $row['medicineid']; ?>"
class="btn btn-sm btn-danger"

onclick="return confirm('Are you sure you want to delete this medicine?');">

Delete

</a>

</td>


</tr>


<?php

}

}

else

{

?>


<tr>

<td
colspan="7"
class="text-center py-5">

<h5 class="fw-bold">
No Medicine Found
</h5>

<p class="text-muted">
No medicine has been added yet.
</p>

<a
href="add.php"
class="btn btn-primary">

+ Add Medicine

</a>

</td>

</tr>


<?php

}

?>


</tbody>

</table>

</div>

</div>

</div>

</body>

</html>