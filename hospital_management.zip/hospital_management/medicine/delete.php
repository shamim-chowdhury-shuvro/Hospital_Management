<?php

require_once "../db.php";


if(!isset($_GET['id']) || empty($_GET['id']))
{
    header("Location:view.php");
    exit();
}


$id = $_GET['id'];


/*
|--------------------------------------------------------------------------
| Check Whether Medicine Is Used In Prescription
|--------------------------------------------------------------------------
*/

$check = mysqli_query(
    $db,
    "SELECT *
     FROM prescription_medicine
     WHERE medicineid='$id'"
);


if(mysqli_num_rows($check) > 0)
{

    echo "

    <script>

    alert(
        'This medicine cannot be deleted because it is already used in a prescription.'
    );

    window.location='view.php';

    </script>

    ";

    exit();
}


/*
|--------------------------------------------------------------------------
| Delete Medicine
|--------------------------------------------------------------------------
*/

$delete = mysqli_query(
    $db,
    "DELETE FROM medicine
     WHERE medicineid='$id'"
);


if($delete)
{
    header("Location:view.php");
    exit();
}
else
{
    echo "Unable to delete medicine: " .
         mysqli_error($db);
}

?>