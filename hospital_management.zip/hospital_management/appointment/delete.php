<?php

require_once "../db.php";

$id = $_GET['id'];

$sql = "DELETE FROM appointment
        WHERE appointmentid='$id'";

if(mysqli_query($db,$sql))
{
    header("Location: view.php");
    exit();
}
else
{
    echo "Delete Failed";
}

?>