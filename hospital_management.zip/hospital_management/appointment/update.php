<?php

require_once "../db.php";

$id = $_GET['id'];

$patients = mysqli_query($db,"SELECT * FROM patient");
$doctors = mysqli_query($db,"SELECT * FROM doctor");

$sql = "SELECT * FROM appointment
        WHERE appointmentid='$id'";

$result = mysqli_query($db,$sql);

$row = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $patientid = $_POST['patientid'];
    $doctorid = $_POST['doctorid'];
    $appointmentdate = $_POST['appointmentdate'];
    $appointmenttime = $_POST['appointmenttime'];
    $status = $_POST['status'];

    $sql = "UPDATE appointment
            SET
            patientid='$patientid',
            doctorid='$doctorid',
            appointmentdate='$appointmentdate',
            appointmenttime='$appointmenttime',
            status='$status'
            WHERE appointmentid='$id'";

    if(mysqli_query($db,$sql))
    {
        header("Location: view.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Update Appointment</title>
</head>
<body>

<h2>Update Appointment</h2>

<form method="POST">

Patient:

<select name="patientid">

<?php
while($p = mysqli_fetch_assoc($patients))
{
?>

<option
value="<?php echo $p['patientid']; ?>"

<?php
if($p['patientid'] == $row['patientid'])
{
    echo "selected";
}
?>

>

<?php echo $p['patientname']; ?>

</option>

<?php
}
?>

</select>

<br><br>

Doctor:

<select name="doctorid">

<?php
while($d = mysqli_fetch_assoc($doctors))
{
?>

<option
value="<?php echo $d['doctorid']; ?>"

<?php
if($d['doctorid'] == $row['doctorid'])
{
    echo "selected";
}
?>

>

<?php echo $d['doctorname']; ?>

</option>

<?php
}
?>

</select>

<br><br>

Date:

<input type="date"
       name="appointmentdate"
       value="<?php echo $row['appointmentdate']; ?>">

<br><br>

Time:

<input type="time"
       name="appointmenttime"
       value="<?php echo $row['appointmenttime']; ?>">

<br><br>

Status:

<input type="text"
       name="status"
       value="<?php echo $row['status']; ?>">

<br><br>

<input type="submit"
       name="update"
       value="Update Appointment">

</form>

<br><br>

<a href="../dashboard.php">
Back To Dashboard
</a>

</body>
</html>