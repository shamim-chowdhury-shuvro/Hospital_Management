<?php

require_once "../db.php";

$result = mysqli_query(
    $db,
    "SELECT
        a.appointmentid,
        a.patientid,
        a.doctorid,
        a.appointmentdate,
        a.appointmenttime,
        a.status,
        p.patientname,
        d.doctorname,
        d.specialization
     FROM appointment a
     LEFT JOIN patient p
        ON a.patientid = p.patientid
     LEFT JOIN doctor d
        ON a.doctorid = d.doctorid
     ORDER BY a.appointmentdate DESC,
              a.appointmenttime DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<title>Appointment Management - Hospital Management System</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

</head>

<body>

<div class="container-fluid mt-4 mb-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Appointment Management
</h2>

<p class="text-muted mb-0">
View and manage patient appointments
</p>

</div>

<div>

<a
href="add.php"
class="btn btn-primary">

+ Add Appointment

</a>

<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>

</div>

<div class="table-card">

<div class="table-responsive">

<table class="table table-hover table-bordered align-middle">

<thead class="table-warning">

<tr>

<th>ID</th>

<th>Patient</th>

<th>Doctor</th>

<th>Specialization</th>

<th>Date</th>

<th>Time</th>

<th>Status</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php

if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_assoc($result))
{

?>

<tr>

<td>
<?php echo $row['appointmentid']; ?>
</td>

<td>

<strong>

<?php

echo htmlspecialchars(
    $row['patientname'] ?? 'Unknown Patient'
);

?>

</strong>

</td>

<td>

<?php

echo htmlspecialchars(
    $row['doctorname'] ?? 'Unknown Doctor'
);

?>

</td>

<td>

<?php

echo htmlspecialchars(
    $row['specialization'] ?? '-'
);

?>

</td>

<td>

<?php

echo htmlspecialchars(
    $row['appointmentdate']
);

?>

</td>

<td>

<?php

echo htmlspecialchars(
    $row['appointmenttime']
);

?>

</td>

<td>

<?php

$status = $row['status'];

if($status == "Scheduled")
{

?>

<span class="badge bg-primary">
Scheduled
</span>

<?php

}
elseif($status == "Completed")
{

?>

<span class="badge bg-success">
Completed
</span>

<?php

}
elseif($status == "Cancelled")
{

?>

<span class="badge bg-danger">
Cancelled
</span>

<?php

}
else
{

?>

<span class="badge bg-secondary">

<?php echo htmlspecialchars($status); ?>

</span>

<?php

}

?>

</td>

<td>

<a
href="update.php?id=<?php echo $row['appointmentid']; ?>"
class="btn btn-sm btn-warning">

Edit

</a>

<a
href="delete.php?id=<?php echo $row['appointmentid']; ?>"
class="btn btn-sm btn-danger"
onclick="return confirm('Are you sure you want to delete this appointment?');">

Delete

</a>

</td>

</tr>

<?php

}

}
else
{

?>

<tr>

<td
colspan="8"
class="text-center text-muted py-4">

No appointments found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

</body>

</html>