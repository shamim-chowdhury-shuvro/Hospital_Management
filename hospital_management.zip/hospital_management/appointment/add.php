<?php

require_once "../db.php";

$patients = mysqli_query(
    $db,
    "SELECT patientid, patientname FROM patient ORDER BY patientname"
);

$doctors = mysqli_query(
    $db,
    "SELECT doctorid, doctorname, specialization
     FROM doctor
     ORDER BY doctorname"
);

$error = "";

if(isset($_POST['submit']))
{
    $patientid = $_POST['patientid'];
    $doctorid = $_POST['doctorid'];
    $appointmentdate = $_POST['appointmentdate'];
    $appointmenttime = $_POST['appointmenttime'];
    $status = $_POST['status'];

    $sql = "INSERT INTO appointment
    (
        patientid,
        doctorid,
        appointmentdate,
        appointmenttime,
        status
    )
    VALUES
    (
        '$patientid',
        '$doctorid',
        '$appointmentdate',
        '$appointmenttime',
        '$status'
    )";

    if(mysqli_query($db,$sql))
    {
        header("Location:view.php");
        exit();
    }
    else
    {
        $error = mysqli_error($db);
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Add Appointment - Hospital Management System</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

</head>

<body>

<div class="container mt-4 mb-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Add Appointment
</h2>

<p class="text-muted mb-0">
Schedule an appointment for a patient
</p>

</div>

<a
href="../dashboard.php"
class="btn btn-primary">

Dashboard

</a>

</div>

<div class="form-card">

<?php

if($error != "")
{

?>

<div class="alert alert-danger">

<?php echo htmlspecialchars($error); ?>

</div>

<?php

}

?>

<form method="POST">

<div class="row">

<div class="col-md-6 mb-3">

<label class="form-label">
Patient
</label>

<select
name="patientid"
class="form-select"
required>

<option value="">
Select Patient
</option>

<?php

while($p = mysqli_fetch_assoc($patients))
{

?>

<option
value="<?php echo $p['patientid']; ?>">

<?php echo htmlspecialchars($p['patientname']); ?>

</option>

<?php

}

?>

</select>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Doctor
</label>

<select
name="doctorid"
class="form-select"
required>

<option value="">
Select Doctor
</option>

<?php

while($d = mysqli_fetch_assoc($doctors))
{

?>

<option
value="<?php echo $d['doctorid']; ?>">

<?php

echo htmlspecialchars($d['doctorname']);

if(!empty($d['specialization']))
{
    echo " - " . htmlspecialchars($d['specialization']);
}

?>

</option>

<?php

}

?>

</select>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Appointment Date
</label>

<input
type="date"
name="appointmentdate"
class="form-control"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Appointment Time
</label>

<input
type="time"
name="appointmenttime"
class="form-control"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Status
</label>

<select
name="status"
class="form-select"
required>

<option value="Scheduled">
Scheduled
</option>

<option value="Completed">
Completed
</option>

<option value="Cancelled">
Cancelled
</option>

</select>

</div>

</div>

<div class="mt-3">

<button
type="submit"
name="submit"
class="btn btn-primary px-4">

Save Appointment

</button>

<a
href="view.php"
class="btn btn-outline-secondary ms-2">

View Appointments

</a>

</div>

</form>

</div>

</div>

</body>

</html>