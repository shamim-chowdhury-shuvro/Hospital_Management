<?php

session_start();

require_once "db.php";

if(isset($_POST['login']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];

    $result=mysqli_query(
    $db,
    "SELECT *
    FROM users
    WHERE username='$username'
    AND password='$password'"
    );

    if(mysqli_num_rows($result)>0)
    {
        $_SESSION['username']=$username;

        header("Location:dashboard.php");
        exit();
    }

    else
    {
        $error="Invalid Username Or Password";
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Hospital Management Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:linear-gradient(135deg,#2563eb,#1e293b);
height:100vh;
display:flex;
justify-content:center;
align-items:center;
}

.login-card{
width:400px;
border:none;
border-radius:20px;
padding:30px;
box-shadow:0px 10px 30px rgba(0,0,0,.3);
background:white;
}

</style>

</head>

<body>

<div class="login-card">

<h2 class="text-center mb-4">
🏥 HMS Login
</h2>

<?php

if(isset($error))
{
?>

<div class="alert alert-danger">

<?php echo $error; ?>

</div>

<?php
}
?>

<form method="POST">

<div class="mb-3">

<label>Username</label>

<input
type="text"
name="username"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Password</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<button
type="submit"
name="login"
class="btn btn-primary w-100">

Login

</button>

</form>

</div>

</body>

</html>