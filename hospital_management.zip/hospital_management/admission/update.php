<?php

require_once "../db.php";

$error = "";

if(!isset($_GET['id']) || empty($_GET['id']))
{
    header("Location:view.php");
    exit();
}

$id = $_GET['id'];


/*
|--------------------------------------------------------------------------
| Get Current Admission
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $db,
    "SELECT *
     FROM admission
     WHERE admissionid='$id'"
);

if(mysqli_num_rows($result) == 0)
{
    header("Location:view.php");
    exit();
}

$row = mysqli_fetch_assoc($result);


/*
|--------------------------------------------------------------------------
| Get Patients
|--------------------------------------------------------------------------
*/

$patients = mysqli_query(
    $db,
    "SELECT patientid, patientname, patienttype
     FROM patient
     ORDER BY patientname"
);


/*
|--------------------------------------------------------------------------
| Get Wards
|--------------------------------------------------------------------------
*/

$wards = mysqli_query(
    $db,
    "SELECT wardid, wardname, wardtype
     FROM ward
     ORDER BY wardname"
);


/*
|--------------------------------------------------------------------------
| Get Available Beds + Current Bed
|--------------------------------------------------------------------------
*/

$beds = mysqli_query(
    $db,
    "SELECT bedid, wardid, bednumber, status
     FROM bed
     WHERE status='Available'
        OR bedid='".$row['bedid']."'
     ORDER BY bednumber"
);


/*
|--------------------------------------------------------------------------
| Update Admission
|--------------------------------------------------------------------------
*/

if(isset($_POST['update']))
{
    $patientid = $_POST['patientid'];
    $wardid = $_POST['wardid'];
    $bedid = $_POST['bedid'];
    $admitdate = $_POST['admitdate'];
    $status = $_POST['status'];
    $dischargedate = !empty($_POST['dischargedate'])
        ? $_POST['dischargedate']
        : NULL;


    /*
     * Current Bed
     */

    $oldbedid = $row['bedid'];


    /*
     * If status is Discharged,
     * discharge date is required
     */

    if($status == "Discharged" && empty($dischargedate))
    {
        $error = "Please select a discharge date.";
    }


    /*
     * If status is Admitted,
     * discharge date should be NULL
     */

    if($status == "Admitted")
    {
        $dischargedate = NULL;
    }


    /*
     * Check selected bed availability
     */

    if($error == "")
    {
        $checkbed = mysqli_query(
            $db,
            "SELECT bedid, status
             FROM bed
             WHERE bedid='$bedid'"
        );

        if(mysqli_num_rows($checkbed) == 0)
        {
            $error = "Selected bed does not exist.";
        }
        else
        {
            $selectedBed = mysqli_fetch_assoc($checkbed);

            /*
             * Allow current bed even if it is Occupied.
             * Other occupied beds cannot be selected.
             */

            if(
                $bedid != $oldbedid &&
                $selectedBed['status'] != "Available"
            )
            {
                $error = "Selected bed is not available.";
            }
        }
    }


    /*
     * Update Database
     */

    if($error == "")
    {

        if($dischargedate === NULL)
        {

            $sql = "UPDATE admission

                    SET
                        patientid='$patientid',
                        wardid='$wardid',
                        bedid='$bedid',
                        admitdate='$admitdate',
                        dischargedate=NULL,
                        status='$status'

                    WHERE admissionid='$id'";
        }
        else
        {

            $sql = "UPDATE admission

                    SET
                        patientid='$patientid',
                        wardid='$wardid',
                        bedid='$bedid',
                        admitdate='$admitdate',
                        dischargedate='$dischargedate',
                        status='$status'

                    WHERE admissionid='$id'";
        }


        if(mysqli_query($db,$sql))
        {

            /*
             * If bed was changed,
             * make old bed available
             */

            if($oldbedid != $bedid)
            {
                mysqli_query(
                    $db,
                    "UPDATE bed
                     SET status='Available'
                     WHERE bedid='$oldbedid'"
                );
            }


            /*
             * If patient is admitted,
             * selected bed becomes Occupied
             */

            if($status == "Admitted")
            {
                mysqli_query(
                    $db,
                    "UPDATE bed
                     SET status='Occupied'
                     WHERE bedid='$bedid'"
                );
            }


            /*
             * If patient is discharged,
             * selected bed becomes Available
             */

            if($status == "Discharged")
            {
                mysqli_query(
                    $db,
                    "UPDATE bed
                     SET status='Available'
                     WHERE bedid='$bedid'"
                );
            }


            header("Location:view.php");
            exit();
        }
        else
        {
            $error = mysqli_error($db);
        }
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>
Update Admission - Hospital Management System
</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

<style>

.update-card
{
    max-width:900px;
    margin:auto;
    background:white;
    border-radius:20px;
    padding:30px;
    box-shadow:0 5px 20px rgba(0,0,0,.08);
}

</style>

</head>

<body>


<div class="container mt-4 mb-5">


<!-- HEADER -->

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Update Admission
</h2>

<p class="text-muted mb-0">
Edit patient admission information
</p>

</div>

<a
href="view.php"
class="btn btn-outline-secondary">

Back

</a>

</div>


<!-- CARD -->

<div class="update-card">


<?php

if($error != "")
{

?>

<div class="alert alert-danger">

<?php

echo htmlspecialchars($error);

?>

</div>

<?php

}

?>


<form method="POST">


<div class="row">


<!-- PATIENT -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">

Patient

</label>

<select
name="patientid"
class="form-select"
required>

<?php

while($p = mysqli_fetch_assoc($patients))
{

?>

<option
value="<?php echo $p['patientid']; ?>"

<?php

if($p['patientid'] == $row['patientid'])
{
    echo "selected";
}

?>

>

<?php

echo htmlspecialchars(
    $p['patientname']
);

echo " - ";

echo htmlspecialchars(
    $p['patienttype']
);

?>

</option>

<?php

}

?>

</select>

</div>


<!-- WARD -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">

Ward

</label>

<select
name="wardid"
id="wardid"
class="form-select"
required>

<?php

while($w = mysqli_fetch_assoc($wards))
{

?>

<option
value="<?php echo $w['wardid']; ?>"

<?php

if($w['wardid'] == $row['wardid'])
{
    echo "selected";
}

?>

>

<?php

echo htmlspecialchars(
    $w['wardname']
);

if(!empty($w['wardtype']))
{
    echo " - " . htmlspecialchars(
        $w['wardtype']
    );
}

?>

</option>

<?php

}

?>

</select>

</div>


<!-- BED -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">

Bed

</label>

<select
name="bedid"
id="bedid"
class="form-select"
required>

<?php

while($b = mysqli_fetch_assoc($beds))
{

?>

<option
value="<?php echo $b['bedid']; ?>"

data-ward="<?php echo $b['wardid']; ?>"

<?php

if($b['bedid'] == $row['bedid'])
{
    echo "selected";
}

?>

>

Bed

<?php

echo htmlspecialchars(
    $b['bednumber']
);

?>

<?php

if($b['bedid'] == $row['bedid'])
{
    echo " (Current Bed)";
}

?>

</option>

<?php

}

?>

</select>

</div>


<!-- ADMIT DATE -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">

Admission Date

</label>

<input
type="date"
name="admitdate"
class="form-control"
value="<?php echo htmlspecialchars($row['admitdate']); ?>"
required>

</div>


<!-- STATUS -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">

Status

</label>

<select
name="status"
id="status"
class="form-select"
required>

<option
value="Admitted"

<?php

if($row['status'] == "Admitted")
{
    echo "selected";
}

?>

>

Admitted

</option>

<option
value="Discharged"

<?php

if($row['status'] == "Discharged")
{
    echo "selected";
}

?>

>

Discharged

</option>

</select>

</div>


<!-- DISCHARGE DATE -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">

Discharge Date

</label>

<input
type="date"
name="dischargedate"
id="dischargedate"
class="form-control"

value="<?php

echo htmlspecialchars(
    $row['dischargedate'] ?? ''
);

?>"

<?php

if($row['status'] == "Discharged")
{
    echo "required";
}

?>

>

</div>


</div>


<!-- WARNING -->

<div class="alert alert-info mt-3">

<strong>Bed Management:</strong>

<ul class="mb-0 mt-2">

<li>
Changing the bed will make the old bed available.
</li>

<li>
An admitted patient keeps the selected bed occupied.
</li>

<li>
A discharged patient makes the selected bed available.
</li>

</ul>

</div>


<!-- BUTTONS -->

<div class="mt-4">

<button
type="submit"
name="update"
class="btn btn-primary px-4">

Update Admission

</button>

<a
href="view.php"
class="btn btn-outline-secondary ms-2">

Cancel

</a>

<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>


</form>


</div>

</div>


<script>

/*
|--------------------------------------------------------------------------
| Filter beds according to selected ward
|--------------------------------------------------------------------------
*/

function filterBeds()
{

    const ward =
        document.getElementById("wardid").value;

    const bed =
        document.getElementById("bedid");

    const options =
        bed.querySelectorAll("option");


    options.forEach(function(option)
    {

        if(option.value === "")
        {
            return;
        }


        if(
            option.getAttribute("data-ward")
            === ward
        )
        {
            option.style.display = "block";
        }
        else
        {
            option.style.display = "none";
        }

    });

}


/*
|--------------------------------------------------------------------------
| Ward change
|--------------------------------------------------------------------------
*/

document
.getElementById("wardid")
.addEventListener(
    "change",
    filterBeds
);


/*
|--------------------------------------------------------------------------
| Discharge Date requirement
|--------------------------------------------------------------------------
*/

function checkStatus()
{

    const status =
        document.getElementById("status").value;

    const dischargeDate =
        document.getElementById("dischargedate");


    if(status === "Discharged")
    {
        dischargeDate.required = true;
    }
    else
    {
        dischargeDate.required = false;
    }

}


document
.getElementById("status")
.addEventListener(
    "change",
    checkStatus
);


/*
|--------------------------------------------------------------------------
| Run on page load
|--------------------------------------------------------------------------
*/

filterBeds();

checkStatus();

</script>


</body>

</html>