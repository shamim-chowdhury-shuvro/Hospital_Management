<?php

require_once "../db.php";

$error = "";

$patients = mysqli_query(
    $db,
    "SELECT patientid, patientname, patienttype
     FROM patient
     ORDER BY patientname"
);

$wards = mysqli_query(
    $db,
    "SELECT wardid, wardname, wardtype
     FROM ward
     ORDER BY wardname"
);

$beds = mysqli_query(
    $db,
    "SELECT bedid, wardid, bednumber
     FROM bed
     WHERE status='Available'
     ORDER BY bednumber"
);

if(isset($_POST['submit']))
{
    $patientid = $_POST['patientid'];
    $patienttype = $_POST['patienttype'];
    $admitdate = $_POST['admitdate'];

    $wardid = !empty($_POST['wardid'])
        ? $_POST['wardid']
        : NULL;

    $bedid = !empty($_POST['bedid'])
        ? $_POST['bedid']
        : NULL;


    /*
     * Outdoor patient
     * Ward and Bed are not required
     */

    if($patienttype == "Outdoor")
    {
        $wardid = NULL;
        $bedid = NULL;
    }


    /*
     * Indoor patient must have
     * Ward and Bed
     */

    if($patienttype == "Indoor")
    {
        if($wardid === NULL || $bedid === NULL)
        {
            $error = "Indoor patient-এর জন্য Ward এবং Bed select করতে হবে.";
        }
    }


    if($error == "")
    {

        /*
         * Check whether selected bed is still available
         */

        if($bedid !== NULL)
        {
            $checkbed = mysqli_query(
                $db,
                "SELECT bedid
                 FROM bed
                 WHERE bedid='$bedid'
                 AND status='Available'"
            );

            if(mysqli_num_rows($checkbed) == 0)
            {
                $error = "Selected bed is no longer available.";
            }
        }
    }


    if($error == "")
    {

        /*
         * Insert Admission
         */

        if($wardid === NULL && $bedid === NULL)
        {
            $sql = "INSERT INTO admission
            (
                patientid,
                wardid,
                bedid,
                admitdate
            )
            VALUES
            (
                '$patientid',
                NULL,
                NULL,
                '$admitdate'
            )";
        }
        else
        {
            $sql = "INSERT INTO admission
            (
                patientid,
                wardid,
                bedid,
                admitdate
            )
            VALUES
            (
                '$patientid',
                '$wardid',
                '$bedid',
                '$admitdate'
            )";
        }


        if(mysqli_query($db,$sql))
        {

            /*
             * Occupy bed only for Indoor admission
             */

            if($bedid !== NULL)
            {
                mysqli_query(
                    $db,
                    "UPDATE bed
                     SET status='Occupied'
                     WHERE bedid='$bedid'"
                );
            }

            header("Location:view.php");
            exit();
        }
        else
        {
            $error = mysqli_error($db);
        }
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Add Admission - Hospital Management System</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

<style>

.admission-card{
    background:white;
    border-radius:20px;
    padding:30px;
    box-shadow:0 5px 20px rgba(0,0,0,.08);
}

.patient-type-box{
    border-radius:12px;
    padding:12px 15px;
    background:#f8fafc;
    border:1px solid #e2e8f0;
}

</style>

</head>

<body>

<div class="container mt-4 mb-5">

<!-- HEADER -->

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Add Admission
</h2>

<p class="text-muted mb-0">
Admit a patient to the hospital
</p>

</div>

<a
href="../dashboard.php"
class="btn btn-primary">

Dashboard

</a>

</div>


<!-- FORM CARD -->

<div class="admission-card">

<?php

if($error != "")
{

?>

<div class="alert alert-danger">

<?php echo htmlspecialchars($error); ?>

</div>

<?php

}

?>


<form method="POST">


<!-- PATIENT -->

<div class="row">

<div class="col-md-8 mb-3">

<label class="form-label fw-semibold">
Patient
</label>

<select
name="patientid"
id="patientid"
class="form-select"
required
onchange="setPatientType()">

<option value="">
Select Patient
</option>

<?php

while($p = mysqli_fetch_assoc($patients))
{

?>

<option
value="<?php echo $p['patientid']; ?>"
data-type="<?php echo $p['patienttype']; ?>">

<?php

echo htmlspecialchars($p['patientname']);

echo " - ";

echo htmlspecialchars($p['patienttype']);

?>

</option>

<?php

}

?>

</select>

</div>


<!-- PATIENT TYPE -->

<div class="col-md-4 mb-3">

<label class="form-label fw-semibold">
Patient Type
</label>

<input
type="text"
id="patienttype_display"
class="form-control"
value=""
placeholder="Auto detected"
readonly>

<input
type="hidden"
name="patienttype"
id="patienttype">

</div>

</div>


<!-- INDOOR SECTION -->

<div
id="indoorSection"
style="display:none;">

<div class="patient-type-box mb-4">

<h5 class="fw-bold text-primary">
Indoor Admission
</h5>

<p class="text-muted mb-0">
Indoor patients require a ward and an available bed.
</p>

</div>


<div class="row">


<!-- WARD -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">
Ward
</label>

<select
name="wardid"
id="wardid"
class="form-select">

<option value="">
Select Ward
</option>

<?php

while($w = mysqli_fetch_assoc($wards))
{

?>

<option
value="<?php echo $w['wardid']; ?>">

<?php

echo htmlspecialchars($w['wardname']);

if(!empty($w['wardtype']))
{
    echo " - " . htmlspecialchars($w['wardtype']);
}

?>

</option>

<?php

}

?>

</select>

</div>


<!-- BED -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">
Available Bed
</label>

<select
name="bedid"
id="bedid"
class="form-select">

<option value="">
Select Available Bed
</option>

<?php

while($b = mysqli_fetch_assoc($beds))
{

?>

<option
value="<?php echo $b['bedid']; ?>"
data-ward="<?php echo $b['wardid']; ?>">

Bed <?php echo htmlspecialchars($b['bednumber']); ?>

</option>

<?php

}

?>

</select>

</div>

</div>

</div>


<!-- OUTDOOR MESSAGE -->

<div
id="outdoorSection"
style="display:none;">

<div class="alert alert-info">

<strong>Outdoor Patient</strong>

<br>

This patient will be registered as an outdoor admission.
Ward and bed assignment is not required.

</div>

</div>


<!-- ADMIT DATE -->

<div class="col-md-6 mb-3">

<label class="form-label fw-semibold">
Admission Date
</label>

<input
type="date"
name="admitdate"
class="form-control"
required>

</div>


<!-- BUTTONS -->

<div class="mt-4">

<button
type="submit"
name="submit"
class="btn btn-primary px-4">

Admit Patient

</button>

<a
href="view.php"
class="btn btn-outline-secondary ms-2">

View Admissions

</a>

</div>


</form>

</div>

</div>


<script>

function setPatientType()
{
    const patientSelect =
        document.getElementById("patientid");

    const selectedOption =
        patientSelect.options[
            patientSelect.selectedIndex
        ];

    const type =
        selectedOption.getAttribute("data-type");

    const typeDisplay =
        document.getElementById(
            "patienttype_display"
        );

    const typeHidden =
        document.getElementById(
            "patienttype"
        );

    const indoorSection =
        document.getElementById(
            "indoorSection"
        );

    const outdoorSection =
        document.getElementById(
            "outdoorSection"
        );

    const ward =
        document.getElementById(
            "wardid"
        );

    const bed =
        document.getElementById(
            "bedid"
        );


    typeDisplay.value = type || "";

    typeHidden.value = type || "";


    if(type === "Indoor")
    {
        indoorSection.style.display = "block";

        outdoorSection.style.display = "none";

        ward.required = true;

        bed.required = true;
    }
    else if(type === "Outdoor")
    {
        indoorSection.style.display = "none";

        outdoorSection.style.display = "block";

        ward.required = false;

        bed.required = false;

        ward.value = "";

        bed.value = "";
    }
    else
    {
        indoorSection.style.display = "none";

        outdoorSection.style.display = "none";

        ward.required = false;

        bed.required = false;
    }
}


/*
 * Show only beds belonging to selected ward
 */

document.getElementById("wardid")
.addEventListener("change", function()
{

    const selectedWard = this.value;

    const bedSelect =
        document.getElementById("bedid");

    const options =
        bedSelect.querySelectorAll("option");


    bedSelect.value = "";


    options.forEach(function(option)
    {

        if(option.value === "")
        {
            option.style.display = "block";
            return;
        }


        if(
            selectedWard === "" ||
            option.getAttribute("data-ward")
            === selectedWard
        )
        {
            option.style.display = "block";
        }
        else
        {
            option.style.display = "none";
        }

    });

});

</script>


</body>

</html>