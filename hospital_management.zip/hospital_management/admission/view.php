<?php

require_once "../db.php";


$result = mysqli_query(
    $db,
    "SELECT
        a.admissionid,
        a.patientid,
        a.wardid,
        a.bedid,
        a.admitdate,
        a.dischargedate,
        a.status,

        p.patientname,
        p.patienttype,

        w.wardname,
        w.wardtype,

        b.bednumber,
        b.status AS bedstatus

     FROM admission a

     LEFT JOIN patient p
        ON a.patientid = p.patientid

     LEFT JOIN ward w
        ON a.wardid = w.wardid

     LEFT JOIN bed b
        ON a.bedid = b.bedid

     ORDER BY a.admissionid DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<title>
Admission Management - Hospital Management System
</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

</head>

<body>


<div class="container-fluid mt-4 mb-5">


<!-- HEADER -->

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Admission Management
</h2>

<p class="text-muted mb-0">
View and manage patient admissions
</p>

</div>


<div>

<a
href="add.php"
class="btn btn-primary">

+ Add Admission

</a>

<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>

</div>


<!-- TABLE -->

<div class="table-card">

<div class="table-responsive">

<table
class="table table-hover table-bordered align-middle">


<thead class="table-primary">

<tr>

<th>
ID
</th>

<th>
Patient
</th>

<th>
Patient Type
</th>

<th>
Ward
</th>

<th>
Bed
</th>

<th>
Admission Date
</th>

<th>
Discharge Date
</th>

<th>
Status
</th>

<th>
Action
</th>

</tr>

</thead>


<tbody>


<?php

if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_assoc($result))
{

?>


<tr>


<!-- ID -->

<td>

<?php

echo $row['admissionid'];

?>

</td>


<!-- PATIENT -->

<td>

<strong>

<?php

echo htmlspecialchars(
    $row['patientname']
    ?? 'Unknown Patient'
);

?>

</strong>

</td>


<!-- PATIENT TYPE -->

<td>

<?php

if(
    isset($row['patienttype'])
    &&
    $row['patienttype'] == "Indoor"
)
{

?>

<span class="badge bg-primary">
Indoor
</span>

<?php

}
else
{

?>

<span class="badge bg-info text-dark">
Outdoor
</span>

<?php

}

?>

</td>


<!-- WARD -->

<td>

<?php

if(!empty($row['wardname']))
{

echo htmlspecialchars(
    $row['wardname']
);

if(!empty($row['wardtype']))
{

echo "<br>";

echo "<small class='text-muted'>";

echo htmlspecialchars(
    $row['wardtype']
);

echo "</small>";

}

}
else
{

?>

<span class="text-muted">
Not Assigned
</span>

<?php

}

?>

</td>


<!-- BED -->

<td>

<?php

if(!empty($row['bednumber']))
{

echo "Bed ";

echo htmlspecialchars(
    $row['bednumber']
);

}
else
{

?>

<span class="text-muted">
Not Assigned
</span>

<?php

}

?>

</td>


<!-- ADMISSION DATE -->

<td>

<?php

echo htmlspecialchars(
    $row['admitdate']
);

?>

</td>


<!-- DISCHARGE DATE -->

<td>

<?php

if(!empty($row['dischargedate']))
{

echo htmlspecialchars(
    $row['dischargedate']
);

}
else
{

?>

<span class="text-muted">
Not Discharged
</span>

<?php

}

?>

</td>


<!-- STATUS -->

<td>

<?php

if($row['status'] == "Admitted")
{

?>

<span class="badge bg-success">
Admitted
</span>

<?php

}
elseif($row['status'] == "Discharged")
{

?>

<span class="badge bg-secondary">
Discharged
</span>

<?php

}
else
{

?>

<span class="badge bg-warning text-dark">

<?php

echo htmlspecialchars(
    $row['status']
);

?>

</span>

<?php

}

?>

</td>


<!-- ACTION -->

<td>

<a
href="update.php?id=<?php echo $row['admissionid']; ?>"
class="btn btn-sm btn-warning mb-1">

Edit

</a>


<?php

if($row['status'] == "Admitted")
{

?>

<a
href="discharge.php?id=<?php echo $row['admissionid']; ?>"
class="btn btn-sm btn-danger mb-1">

Discharge

</a>

<?php

}

?>


<a
href="delete.php?id=<?php echo $row['admissionid']; ?>"
class="btn btn-sm btn-outline-danger mb-1"
onclick="return confirm('Are you sure you want to delete this admission?');">

Delete

</a>

</td>


</tr>


<?php

}

}
else
{

?>


<tr>

<td
colspan="9"
class="text-center text-muted py-4">

No admissions found.

</td>

</tr>


<?php

}

?>


</tbody>

</table>

</div>

</div>


</div>


</body>

</html>