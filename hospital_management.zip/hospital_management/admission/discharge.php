<?php

require_once "../db.php";

if(!isset($_GET['id']) || empty($_GET['id']))
{
    header("Location:view.php");
    exit();
}

$admissionid = $_GET['id'];

$error = "";
$success = "";


/*
|--------------------------------------------------------------------------
| Get Admission Information
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $db,
    "SELECT
        a.admissionid,
        a.patientid,
        a.wardid,
        a.bedid,
        a.admitdate,
        a.dischargedate,
        a.status,

        p.patientname,
        p.patienttype,

        w.wardname,

        b.bednumber

     FROM admission a

     LEFT JOIN patient p
        ON a.patientid = p.patientid

     LEFT JOIN ward w
        ON a.wardid = w.wardid

     LEFT JOIN bed b
        ON a.bedid = b.bedid

     WHERE a.admissionid='$admissionid'"
);


if(mysqli_num_rows($result) == 0)
{
    header("Location:view.php");
    exit();
}


$admission = mysqli_fetch_assoc($result);


/*
|--------------------------------------------------------------------------
| Discharge Patient
|--------------------------------------------------------------------------
*/

if(isset($_POST['discharge']))
{
    $dischargedate = $_POST['dischargedate'];


    /*
     * Check if already discharged
     */

    if($admission['status'] == "Discharged")
    {
        $error = "This patient has already been discharged.";
    }
    else
    {

        /*
         * Update admission
         */

        $update = mysqli_query(
            $db,
            "UPDATE admission

             SET
                dischargedate='$dischargedate',
                status='Discharged'

             WHERE admissionid='$admissionid'"
        );


        if($update)
        {

            /*
             * Make bed available again
             */

            if(!empty($admission['bedid']))
            {
                mysqli_query(
                    $db,
                    "UPDATE bed

                     SET status='Available'

                     WHERE bedid='".$admission['bedid']."'"
                );
            }


            header("Location:view.php");
            exit();
        }
        else
        {
            $error = mysqli_error($db);
        }
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>
Discharge Patient - Hospital Management System
</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

<style>

.discharge-card
{
    max-width:850px;
    margin:auto;
    background:white;
    border-radius:20px;
    padding:35px;
    box-shadow:0 5px 25px rgba(0,0,0,.08);
}

.patient-info
{
    background:#f8fafc;
    border-radius:15px;
    padding:20px;
    margin-bottom:25px;
}

.info-label
{
    font-size:13px;
    color:#64748b;
    margin-bottom:3px;
}

.info-value
{
    font-weight:600;
    color:#1e293b;
}

</style>

</head>

<body>

<div class="container mt-5 mb-5">


<div class="discharge-card">


<!-- HEADER -->

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold mb-1">
Discharge Patient
</h2>

<p class="text-muted mb-0">
Complete patient discharge
</p>

</div>

<a
href="view.php"
class="btn btn-outline-secondary">

Back

</a>

</div>


<?php

if($error != "")
{

?>

<div class="alert alert-danger">

<?php echo htmlspecialchars($error); ?>

</div>

<?php

}

?>


<!-- PATIENT INFORMATION -->

<div class="patient-info">

<h5 class="fw-bold mb-4">
Admission Information
</h5>


<div class="row">


<div class="col-md-6 mb-3">

<div class="info-label">
Patient
</div>

<div class="info-value">

<?php

echo htmlspecialchars(
    $admission['patientname']
);

?>

</div>

</div>


<div class="col-md-6 mb-3">

<div class="info-label">
Patient Type
</div>

<div class="info-value">

<?php

echo htmlspecialchars(
    $admission['patienttype']
);

?>

</div>

</div>


<div class="col-md-6 mb-3">

<div class="info-label">
Ward
</div>

<div class="info-value">

<?php

echo htmlspecialchars(
    $admission['wardname']
);

?>

</div>

</div>


<div class="col-md-6 mb-3">

<div class="info-label">
Bed
</div>

<div class="info-value">

Bed

<?php

echo htmlspecialchars(
    $admission['bednumber']
);

?>

</div>

</div>


<div class="col-md-6">

<div class="info-label">
Admission Date
</div>

<div class="info-value">

<?php

echo htmlspecialchars(
    $admission['admitdate']
);

?>

</div>

</div>


<div class="col-md-6">

<div class="info-label">
Current Status
</div>

<div class="info-value">

<?php

if($admission['status'] == "Admitted")
{

?>

<span class="badge bg-success">
Admitted
</span>

<?php

}
else
{

?>

<span class="badge bg-secondary">

<?php

echo htmlspecialchars(
    $admission['status']
);

?>

</span>

<?php

}

?>

</div>

</div>

</div>

</div>


<?php

if($admission['status'] == "Discharged")
{

?>

<div class="alert alert-success">

This patient has already been discharged.

<br>

Discharge Date:

<strong>

<?php

echo htmlspecialchars(
    $admission['dischargedate']
);

?>

</strong>

</div>

<?php

}
else
{

?>


<!-- DISCHARGE FORM -->

<form method="POST">


<div class="mb-4">

<label class="form-label fw-semibold">

Discharge Date

</label>

<input
type="date"
name="dischargedate"
class="form-control"
value="<?php echo date('Y-m-d'); ?>"
required>

</div>


<div class="alert alert-warning">

<strong>Important:</strong>

After discharge:

<ul class="mb-0 mt-2">

<li>
Admission status will become <strong>Discharged</strong>.
</li>

<li>
The assigned bed will become <strong>Available</strong>.
</li>

</ul>

</div>


<div class="mt-4">

<button
type="submit"
name="discharge"
class="btn btn-danger px-4"
onclick="return confirm('Are you sure you want to discharge this patient?');">

Discharge Patient

</button>


<a
href="view.php"
class="btn btn-outline-secondary ms-2">

Cancel

</a>

</div>


</form>


<?php

}

?>


</div>

</div>

</body>

</html>