<?php

require_once "../db.php";


if(
    !isset($_GET['prescriptionid']) ||
    !isset($_GET['medicineid']) ||
    empty($_GET['prescriptionid']) ||
    empty($_GET['medicineid'])
)
{
    header("Location:../prescription/view.php");
    exit();
}


$prescriptionid = $_GET['prescriptionid'];
$medicineid = $_GET['medicineid'];


/*
|--------------------------------------------------------------------------
| Get quantity before deleting
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $db,
    "SELECT quantity
     FROM prescription_medicine
     WHERE prescriptionid='$prescriptionid'
     AND medicineid='$medicineid'"
);


if(mysqli_num_rows($result) == 0)
{
    header(
        "Location:view.php?id=".$prescriptionid
    );
    exit();
}


$row = mysqli_fetch_assoc($result);

$quantity = (int)$row['quantity'];


/*
|--------------------------------------------------------------------------
| Delete prescription medicine
|--------------------------------------------------------------------------
*/

$delete = mysqli_query(
    $db,
    "DELETE FROM prescription_medicine
     WHERE prescriptionid='$prescriptionid'
     AND medicineid='$medicineid'"
);


if($delete)
{
    /*
     * Return quantity to medicine stock
     */

    mysqli_query(
        $db,
        "UPDATE medicine
         SET stock = stock + $quantity
         WHERE medicineid='$medicineid'"
    );


    header(
        "Location:view.php?id=".$prescriptionid
    );

    exit();
}
else
{
    echo "Error deleting medicine: "
         . mysqli_error($db);
}

?>