<?php

require_once "../db.php";


/*
|--------------------------------------------------------------------------
| Check Prescription ID
|--------------------------------------------------------------------------
*/

if(!isset($_GET['id']) || empty($_GET['id']))
{
    header("Location:../prescription/view.php");
    exit();
}


$id = $_GET['id'];


/*
|--------------------------------------------------------------------------
| Get Prescription Information
|--------------------------------------------------------------------------
*/

$prescriptionResult = mysqli_query(
    $db,
    "SELECT
        prescriptionid,
        appointmentid,
        diagnosis,
        prescriptiondate
     FROM prescription
     WHERE prescriptionid='$id'"
);


if(mysqli_num_rows($prescriptionResult) == 0)
{
    header("Location:../prescription/view.php");
    exit();
}


$prescription = mysqli_fetch_assoc(
    $prescriptionResult
);


/*
|--------------------------------------------------------------------------
| Get Medicines Added To This Prescription
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $db,
    "SELECT
        pm.prescriptionid,
        pm.medicineid,
        pm.quantity,
        m.medicinename,
        m.price

     FROM prescription_medicine pm

     LEFT JOIN medicine m
        ON pm.medicineid = m.medicineid

     WHERE pm.prescriptionid='$id'

     ORDER BY pm.medicineid DESC"
);


?>

<!DOCTYPE html>

<html>

<head>

<title>
Prescription Medicines
</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">


<style>

body
{
    background:#f4f7fb;
}

.page-card
{
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 5px 25px rgba(0,0,0,.07);
}

.info-card
{
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 5px 25px rgba(0,0,0,.07);
}

.table th
{
    white-space:nowrap;
}

</style>

</head>


<body>


<div class="container-fluid mt-4 mb-5">


<!-- =========================================================
     HEADER
========================================================= -->


<div class="d-flex justify-content-between align-items-center mb-4">


<div>

<h2 class="fw-bold mb-1">

Prescription Medicines

</h2>

<p class="text-muted mb-0">

Medicine list for Prescription ID:

<strong>

<?php

echo $prescription['prescriptionid'];

?>

</strong>

</p>

</div>


<div>

<a
href="../prescription/view.php"
class="btn btn-outline-secondary">

Back To Prescriptions

</a>


<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>


</div>


<!-- =========================================================
     PRESCRIPTION INFORMATION
========================================================= -->


<div class="info-card mb-4">


<div class="row">


<div class="col-md-3">

<strong>
Prescription ID
</strong>

<div class="mt-1">

<?php

echo $prescription['prescriptionid'];

?>

</div>

</div>


<div class="col-md-3">

<strong>
Appointment ID
</strong>

<div class="mt-1">

<?php

echo $prescription['appointmentid'];

?>

</div>

</div>


<div class="col-md-3">

<strong>
Prescription Date
</strong>

<div class="mt-1">

<?php

echo $prescription['prescriptiondate'];

?>

</div>

</div>


<div class="col-md-3">

<strong>
Diagnosis
</strong>

<div class="mt-1">

<?php

echo htmlspecialchars(
    $prescription['diagnosis']
);

?>

</div>

</div>


</div>


</div>


<!-- =========================================================
     ADD MEDICINE BUTTON
========================================================= -->


<div class="mb-3">


<a
href="add.php?id=<?php echo $prescription['prescriptionid']; ?>"
class="btn btn-primary">

+ Add Medicine

</a>


</div>


<!-- =========================================================
     MEDICINE TABLE
========================================================= -->


<div class="page-card">


<div class="table-responsive">


<table class="table table-hover align-middle">


<thead class="table-primary">


<tr>

<th>
Medicine ID
</th>

<th>
Medicine Name
</th>

<th>
Quantity
</th>

<th>
Unit Price
</th>

<th>
Total
</th>

<th>
Action
</th>

</tr>


</thead>


<tbody>


<?php


$grandTotal = 0;


if(mysqli_num_rows($result) > 0)
{


while($row = mysqli_fetch_assoc($result))
{


$quantity = (int)$row['quantity'];

$price = (float)$row['price'];

$total = $quantity * $price;

$grandTotal += $total;


?>


<tr>


<!-- MEDICINE ID -->

<td>

<?php

echo $row['medicineid'];

?>

</td>


<!-- MEDICINE NAME -->

<td>

<strong>

<?php

echo htmlspecialchars(
    $row['medicinename']
);

?>

</strong>

</td>


<!-- QUANTITY -->

<td>

<span class="badge bg-primary">

<?php

echo $quantity;

?>

</span>

</td>


<!-- UNIT PRICE -->

<td>

৳

<?php

echo number_format(
    $price,
    2
);

?>

</td>


<!-- TOTAL -->

<td>

<strong>

৳

<?php

echo number_format(
    $total,
    2
);

?>

</strong>

</td>


<!-- ACTION -->

<td>


<a
href="delete.php?prescriptionid=<?php echo $row['prescriptionid']; ?>&medicineid=<?php echo $row['medicineid']; ?>"
class="btn btn-sm btn-danger"

onclick="return confirm('Are you sure you want to remove this medicine from the prescription?');">

Delete

</a>


</td>


</tr>


<?php

}

}


else

{

?>


<tr>

<td
colspan="6"
class="text-center py-5">


<h5 class="fw-bold">

No Medicine Added

</h5>


<p class="text-muted mb-3">

No medicine has been added to this prescription yet.

</p>


<a
href="add.php?id=<?php echo $prescription['prescriptionid']; ?>"
class="btn btn-primary">

+ Add Medicine

</a>


</td>

</tr>


<?php

}

?>


</tbody>


<?php

if(mysqli_num_rows($result) > 0)

{

?>


<tfoot>


<tr>


<td
colspan="4"
class="text-end fw-bold">

Grand Total

</td>


<td
class="fw-bold">

৳

<?php

echo number_format(
    $grandTotal,
    2
);

?>

</td>


<td>

</td>


</tr>


</tfoot>


<?php

}

?>


</table>


</div>


</div>


</div>


</body>

</html>