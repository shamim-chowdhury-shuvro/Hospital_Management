<?php

require_once "../db.php";


/*
|--------------------------------------------------------------------------
| Check Prescription ID
|--------------------------------------------------------------------------
*/

if(!isset($_GET['id']) || empty($_GET['id']))
{
    header("Location:../prescription/view.php");
    exit();
}

$prescriptionid = $_GET['id'];

$error = "";


/*
|--------------------------------------------------------------------------
| Check Prescription Exists
|--------------------------------------------------------------------------
*/

$prescriptionResult = mysqli_query(
    $db,
    "SELECT prescriptionid
     FROM prescription
     WHERE prescriptionid='$prescriptionid'"
);


if(mysqli_num_rows($prescriptionResult) == 0)
{
    header("Location:../prescription/view.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| Get Medicines With Available Stock
|--------------------------------------------------------------------------
*/

$medicines = mysqli_query(
    $db,
    "SELECT
        medicineid,
        medicinename,
        price,
        stock
     FROM medicine
     WHERE stock > 0
     ORDER BY medicinename ASC"
);


/*
|--------------------------------------------------------------------------
| Add Medicine
|--------------------------------------------------------------------------
*/

if(isset($_POST['submit']))
{

    $medicineid = $_POST['medicineid'];
    $quantity = (int)$_POST['quantity'];


    /*
    |--------------------------------------------------------------------------
    | Validate Quantity
    |--------------------------------------------------------------------------
    */

    if($quantity <= 0)
    {
        $error = "Quantity must be greater than 0.";
    }
    else
    {

        /*
        |--------------------------------------------------------------------------
        | Get Medicine
        |--------------------------------------------------------------------------
        */

        $medicineResult = mysqli_query(
            $db,
            "SELECT
                medicineid,
                medicinename,
                price,
                stock
             FROM medicine
             WHERE medicineid='$medicineid'"
        );


        if(mysqli_num_rows($medicineResult) == 0)
        {
            $error = "Selected medicine was not found.";
        }
        else
        {

            $medicine = mysqli_fetch_assoc(
                $medicineResult
            );


            /*
            |--------------------------------------------------------------------------
            | Check Stock
            |--------------------------------------------------------------------------
            */

            if($quantity > $medicine['stock'])
            {
                $error =
                    "Not enough stock available. " .
                    "Available stock: " .
                    $medicine['stock'];
            }
            else
            {

                /*
                |--------------------------------------------------------------------------
                | Check Duplicate Medicine
                |--------------------------------------------------------------------------
                */

                $existing = mysqli_query(
                    $db,
                    "SELECT quantity
                     FROM prescription_medicine
                     WHERE prescriptionid='$prescriptionid'
                     AND medicineid='$medicineid'"
                );


                if(mysqli_num_rows($existing) > 0)
                {
                    $error =
                        "This medicine is already added to this prescription.";
                }
                else
                {

                    /*
                    |--------------------------------------------------------------------------
                    | Insert Medicine
                    |--------------------------------------------------------------------------
                    */

                    $insert = mysqli_query(
                        $db,
                        "INSERT INTO prescription_medicine
                        (
                            prescriptionid,
                            medicineid,
                            quantity
                        )
                        VALUES
                        (
                            '$prescriptionid',
                            '$medicineid',
                            '$quantity'
                        )"
                    );


                    if($insert)
                    {

                        /*
                        |--------------------------------------------------------------------------
                        | Reduce Medicine Stock
                        |--------------------------------------------------------------------------
                        */

                        $updateStock = mysqli_query(
                            $db,
                            "UPDATE medicine
                             SET stock = stock - $quantity
                             WHERE medicineid='$medicineid'"
                        );


                        if($updateStock)
                        {

                            header(
                                "Location:view.php?id=".$prescriptionid
                            );

                            exit();

                        }
                        else
                        {

                            /*
                            | If stock update fails,
                            | remove inserted prescription medicine
                            */

                            mysqli_query(
                                $db,
                                "DELETE FROM prescription_medicine
                                 WHERE prescriptionid='$prescriptionid'
                                 AND medicineid='$medicineid'"
                            );


                            $error =
                                "Medicine stock could not be updated.";
                        }

                    }
                    else
                    {

                        $error =
                            "Unable to add medicine: " .
                            mysqli_error($db);

                    }

                }

            }

        }

    }

}

?>

<!DOCTYPE html>

<html>

<head>

<title>
Add Medicine To Prescription
</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">


<style>

body
{
    background:#f4f7fb;
}

.form-card
{
    max-width:900px;
    margin:40px auto;
    background:white;
    border-radius:22px;
    padding:40px;
    box-shadow:0 8px 30px rgba(0,0,0,.08);
}

.page-title
{
    font-size:32px;
    font-weight:700;
}

.form-label
{
    font-weight:600;
}

.stock-box
{
    display:none;
}

</style>

</head>


<body>


<div class="container">


<div class="form-card">


<!-- =========================================================
     HEADER
========================================================= -->


<div class="mb-4">


<h2 class="page-title">

Add Medicine To Prescription

</h2>


<p class="text-muted mb-0">

Prescription ID:

<strong>

<?php

echo $prescriptionid;

?>

</strong>

</p>


</div>


<!-- =========================================================
     ERROR MESSAGE
========================================================= -->


<?php

if($error != "")
{

?>

<div class="alert alert-danger">

<?php

echo htmlspecialchars($error);

?>

</div>

<?php

}

?>


<!-- =========================================================
     FORM
========================================================= -->


<form
method="POST"
onsubmit="return validateForm();">


<!-- MEDICINE -->

<div class="mb-4">


<label
for="medicineid"
class="form-label">

Medicine

</label>


<select
name="medicineid"
id="medicineid"
class="form-select"
required>


<option value="">

Select Medicine

</option>


<?php

while($m = mysqli_fetch_assoc($medicines))
{

?>


<option
value="<?php echo $m['medicineid']; ?>"
data-stock="<?php echo $m['stock']; ?>"
data-price="<?php echo $m['price']; ?>">

<?php

echo htmlspecialchars(
    $m['medicinename']
);

?>

&nbsp; — Stock:

<?php

echo $m['stock'];

?>

&nbsp; — ৳

<?php

echo number_format(
    (float)$m['price'],
    2
);

?>

</option>


<?php

}

?>


</select>


</div>


<!-- STOCK INFORMATION -->


<div
id="stockBox"
class="alert alert-info stock-box">


Available Stock:

<strong id="stockValue">

0

</strong>


<br>


Unit Price:

<strong>

৳

<span id="priceValue">
0.00
</span>

</strong>


</div>


<!-- QUANTITY -->


<div class="mb-4">


<label
for="quantity"
class="form-label">

Quantity

</label>


<input
type="number"
name="quantity"
id="quantity"
class="form-control"
min="1"
placeholder="Enter quantity"
required>


<div
class="form-text">

Quantity cannot be greater than available stock.

</div>


</div>


<!-- BUTTONS -->


<div class="mt-4">


<button
type="submit"
name="submit"
class="btn btn-primary px-4">

Add Medicine

</button>


<a
href="view.php?id=<?php echo $prescriptionid; ?>"
class="btn btn-outline-secondary ms-2">

Cancel

</a>


<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>


</div>


</form>


</div>


</div>


<script>


const medicineSelect =
document.getElementById("medicineid");

const quantityInput =
document.getElementById("quantity");

const stockBox =
document.getElementById("stockBox");

const stockValue =
document.getElementById("stockValue");

const priceValue =
document.getElementById("priceValue");


/*
|--------------------------------------------------------------------------
| Show Stock When Medicine Is Selected
|--------------------------------------------------------------------------
*/

medicineSelect.addEventListener(
"change",
function()
{

    const selectedOption =
        this.options[this.selectedIndex];


    const stock =
        selectedOption.getAttribute(
            "data-stock"
        );


    const price =
        selectedOption.getAttribute(
            "data-price"
        );


    if(stock)
    {

        stockValue.innerText =
            stock;


        priceValue.innerText =
            parseFloat(price).toFixed(2);


        quantityInput.max =
            stock;


        stockBox.style.display =
            "block";

    }
    else
    {

        stockBox.style.display =
            "none";


        quantityInput.removeAttribute(
            "max"
        );

    }

});


/*
|--------------------------------------------------------------------------
| Validate Quantity Before Submit
|--------------------------------------------------------------------------
*/

function validateForm()
{

    const selectedOption =
        medicineSelect.options[
            medicineSelect.selectedIndex
        ];


    const stock =
        parseInt(
            selectedOption.getAttribute(
                "data-stock"
            )
        );


    const quantity =
        parseInt(
            quantityInput.value
        );


    if(!medicineSelect.value)
    {

        alert(
            "Please select a medicine."
        );

        return false;

    }


    if(quantity <= 0)
    {

        alert(
            "Quantity must be greater than 0."
        );

        return false;

    }


    if(quantity > stock)
    {

        alert(
            "Quantity cannot be greater than available stock."
        );

        return false;

    }


    return true;

}

</script>


</body>

</html>