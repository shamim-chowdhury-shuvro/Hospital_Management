<?php

require_once "../db.php";

$id = $_GET['id'];

$sql = "DELETE FROM doctor
        WHERE doctorid='$id'";

if(mysqli_query($db,$sql))
{
    header("Location: view.php");
    exit();
}
else
{
    echo "Delete Failed";
}

?>