<?php

require_once "../db.php";

$error = "";

if(isset($_POST['submit']))
{
    $doctorname = $_POST['doctorname'];
    $specialization = $_POST['specialization'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $sql = "INSERT INTO doctor
    (
        doctorname,
        specialization,
        phone,
        email
    )
    VALUES
    (
        '$doctorname',
        '$specialization',
        '$phone',
        '$email'
    )";

    if(mysqli_query($db,$sql))
    {
        header("Location:view.php");
        exit();
    }
    else
    {
        $error = mysqli_error($db);
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Add Doctor - Hospital Management System</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

</head>

<body>

<div class="container mt-4 mb-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Add Doctor
</h2>

<p class="text-muted mb-0">
Register a new doctor
</p>

</div>

<a
href="../dashboard.php"
class="btn btn-primary">

Dashboard

</a>

</div>

<div class="form-card">

<?php

if($error != "")
{

?>

<div class="alert alert-danger">

<?php echo htmlspecialchars($error); ?>

</div>

<?php

}

?>

<form method="POST">

<div class="row">

<div class="col-md-6 mb-3">

<label class="form-label">
Doctor Name
</label>

<input
type="text"
name="doctorname"
class="form-control"
placeholder="Enter doctor name"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Specialization
</label>

<input
type="text"
name="specialization"
class="form-control"
placeholder="e.g. Cardiologist"
required>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Phone
</label>

<input
type="text"
name="phone"
class="form-control"
placeholder="Enter phone number">

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
Email
</label>

<input
type="email"
name="email"
class="form-control"
placeholder="Enter email address">

</div>

</div>

<div class="mt-3">

<button
type="submit"
name="submit"
class="btn btn-primary px-4">

Save Doctor

</button>

<a
href="view.php"
class="btn btn-outline-secondary ms-2">

View Doctors

</a>

</div>

</form>

</div>

</div>

</body>

</html>