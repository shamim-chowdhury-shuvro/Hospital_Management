<?php

require_once "../db.php";

$result = mysqli_query(
    $db,
    "SELECT * FROM doctor ORDER BY doctorid DESC"
);

?>

<!DOCTYPE html>

<html>

<head>

<title>Doctor Management - Hospital Management System</title>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../style.css">

</head>

<body>

<div class="container-fluid mt-4 mb-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<div>

<h2 class="fw-bold">
Doctor Management
</h2>

<p class="text-muted mb-0">
View and manage registered doctors
</p>

</div>

<div>

<a
href="add.php"
class="btn btn-primary">

+ Add Doctor

</a>

<a
href="../dashboard.php"
class="btn btn-outline-dark ms-2">

Dashboard

</a>

</div>

</div>

<div class="table-card">

<div class="table-responsive">

<table class="table table-hover table-bordered align-middle">

<thead class="table-success">

<tr>

<th>ID</th>

<th>Doctor Name</th>

<th>Specialization</th>

<th>Phone</th>

<th>Email</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php

if(mysqli_num_rows($result) > 0)
{

while($row = mysqli_fetch_assoc($result))
{

?>

<tr>

<td>

<?php
echo $row['doctorid'];
?>

</td>

<td>

<strong>

<?php

echo htmlspecialchars(
    $row['doctorname']
);

?>

</strong>

</td>

<td>

<span class="badge bg-success">

<?php

echo htmlspecialchars(
    $row['specialization']
);

?>

</span>

</td>

<td>

<?php

echo htmlspecialchars(
    $row['phone']
);

?>

</td>

<td>

<?php

echo htmlspecialchars(
    $row['email']
);

?>

</td>

<td>

<a
href="update.php?id=<?php echo $row['doctorid']; ?>"
class="btn btn-sm btn-warning">

Edit

</a>

<a
href="delete.php?id=<?php echo $row['doctorid']; ?>"
class="btn btn-sm btn-danger"
onclick="return confirm('Are you sure you want to delete this doctor?');">

Delete

</a>

</td>

</tr>

<?php

}

}
else
{

?>

<tr>

<td
colspan="6"
class="text-center text-muted py-4">

No doctors found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

</body>

</html>