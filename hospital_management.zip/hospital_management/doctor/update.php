<?php

require_once "../db.php";

$id = $_GET['id'];

$dept = mysqli_query($db,"SELECT * FROM department");

$sql = "SELECT * FROM doctor
        WHERE doctorid='$id'";

$result = mysqli_query($db,$sql);

$row = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $doctorname = $_POST['doctorname'];
    $specialization = $_POST['specialization'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $departmentid = $_POST['departmentid'];

    $sql = "UPDATE doctor
            SET
            doctorname='$doctorname',
            specialization='$specialization',
            phone='$phone',
            email='$email',
            departmentid='$departmentid'
            WHERE doctorid='$id'";

    if(mysqli_query($db,$sql))
    {
        header("Location: view.php");
        exit();
    }
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Update Doctor</title>

</head>

<body>

<h2>Update Doctor</h2>

<form method="POST">

    Doctor Name:

    <input type="text"
           name="doctorname"
           value="<?php echo $row['doctorname']; ?>">

    <br><br>

    Specialization:

    <input type="text"
           name="specialization"
           value="<?php echo $row['specialization']; ?>">

    <br><br>

    Phone:

    <input type="text"
           name="phone"
           value="<?php echo $row['phone']; ?>">

    <br><br>

    Email:

    <input type="email"
           name="email"
           value="<?php echo $row['email']; ?>">

    <br><br>

    Department:

    <select name="departmentid">

        <?php

        while($d = mysqli_fetch_assoc($dept))
        {

        ?>

        <option
        value="<?php echo $d['departmentid']; ?>"

        <?php

        if($d['departmentid'] == $row['departmentid'])
        {
            echo "selected";
        }

        ?>

        >

        <?php echo $d['departmentname']; ?>

        </option>

        <?php

        }

        ?>

    </select>

    <br><br>

    <input type="submit"
           name="update"
           value="Update Doctor">

</form>

<br><br>

<a href="../dashboard.php">
Back To Dashboard
</a>

</body>

</html>